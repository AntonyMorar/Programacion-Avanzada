//
//  main.c
//  RailFenceCipher_H4
//
//  Created by Antony Morales on 13/02/19.
//  Copyright © 2019 Antony999k. All rights reserved.
//

#include "rail_fence.h"
#include "pipe.h"

int main(int argc, const char * argv[]) {
    printf("******************************** Rail Fence Cipher Program ********************************\n");
    createProces();
    return 0;
}
